<?php /* Smarty version Smarty-3.1.19, created on 2016-12-09 20:38:05
         compiled from "C:\Bitnami\prestashop-1.6.1.7-1\apps\prestashop\htdocs\administration\themes\default\template\controllers\login\layout.tpl" */ ?>
<?php /*%%SmartyHeaderCode:25024584b86ad32e6d9-02883586%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0bcce64c1267ddfffc240c8891c67483e5867f2e' => 
    array (
      0 => 'C:\\Bitnami\\prestashop-1.6.1.7-1\\apps\\prestashop\\htdocs\\administration\\themes\\default\\template\\controllers\\login\\layout.tpl',
      1 => 1473174312,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '25024584b86ad32e6d9-02883586',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'header' => 0,
    'page' => 0,
    'footer' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_584b86ad337467_33421590',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_584b86ad337467_33421590')) {function content_584b86ad337467_33421590($_smarty_tpl) {?>

<?php echo $_smarty_tpl->tpl_vars['header']->value;?>

<?php echo $_smarty_tpl->tpl_vars['page']->value;?>

<?php echo $_smarty_tpl->tpl_vars['footer']->value;?>
<?php }} ?>
