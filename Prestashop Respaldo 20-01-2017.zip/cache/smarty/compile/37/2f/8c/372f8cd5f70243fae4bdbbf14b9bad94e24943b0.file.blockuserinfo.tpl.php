<?php /* Smarty version Smarty-3.1.19, created on 2016-12-09 20:37:24
         compiled from "C:\Bitnami\prestashop-1.6.1.7-1\apps\prestashop\htdocs\themes\default-bootstrap\modules\blockuserinfo\blockuserinfo.tpl" */ ?>
<?php /*%%SmartyHeaderCode:21503584b86847d7265-46643309%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '372f8cd5f70243fae4bdbbf14b9bad94e24943b0' => 
    array (
      0 => 'C:\\Bitnami\\prestashop-1.6.1.7-1\\apps\\prestashop\\htdocs\\themes\\default-bootstrap\\modules\\blockuserinfo\\blockuserinfo.tpl',
      1 => 1473174314,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '21503584b86847d7265-46643309',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_584b86847d8133_03040442',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_584b86847d8133_03040442')) {function content_584b86847d8133_03040442($_smarty_tpl) {?><?php }} ?>
