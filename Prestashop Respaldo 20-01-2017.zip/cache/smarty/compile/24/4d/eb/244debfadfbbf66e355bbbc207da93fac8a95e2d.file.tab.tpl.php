<?php /* Smarty version Smarty-3.1.19, created on 2016-12-14 23:09:46
         compiled from "C:\Bitnami\prestashop-1.6.1.7-1\apps\prestashop\htdocs\modules\blocknewproducts\views\templates\hook\tab.tpl" */ ?>
<?php /*%%SmartyHeaderCode:52085852178abd1d75-99894831%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '244debfadfbbf66e355bbbc207da93fac8a95e2d' => 
    array (
      0 => 'C:\\Bitnami\\prestashop-1.6.1.7-1\\apps\\prestashop\\htdocs\\modules\\blocknewproducts\\views\\templates\\hook\\tab.tpl',
      1 => 1473174318,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '52085852178abd1d75-99894831',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_5852178abf9bc0_40093694',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5852178abf9bc0_40093694')) {function content_5852178abf9bc0_40093694($_smarty_tpl) {?>
<li><a data-toggle="tab" href="#blocknewproducts" class="blocknewproducts"><?php echo smartyTranslate(array('s'=>'New arrivals','mod'=>'blocknewproducts'),$_smarty_tpl);?>
</a></li>
<?php }} ?>
