<?php /*%%SmartyHeaderCode:2181584b8686cb1838-71823264%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7cf496a0a0436801976ecfc5613e2a39250a1308' => 
    array (
      0 => 'C:\\Bitnami\\prestashop-1.6.1.7-1\\apps\\prestashop\\htdocs\\themes\\default-bootstrap\\modules\\blockmyaccountfooter\\blockmyaccountfooter.tpl',
      1 => 1473174314,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2181584b8686cb1838-71823264',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_58819638d17e73_32043557',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_58819638d17e73_32043557')) {function content_58819638d17e73_32043557($_smarty_tpl) {?><section class="footer-block col-xs-12 col-sm-4"><h4><a href="https://192.168.87.2:446/prestashop/my-account" title="Administrar mi cuenta de cliente" rel="nofollow">Mi cuenta</a></h4><div class="block_content toggle-footer"><ul class="bullet"><li><a href="https://192.168.87.2:446/prestashop/order-history" title="Mis pedidos" rel="nofollow">Mis pedidos</a></li><li><a href="https://192.168.87.2:446/prestashop/credit-slip" title="Mis notas de credito" rel="nofollow">Mis notas de credito</a></li><li><a href="https://192.168.87.2:446/prestashop/addresses" title="Mis direcciones" rel="nofollow">Mis direcciones</a></li><li><a href="https://192.168.87.2:446/prestashop/identity" title="Administrar mi información personal" rel="nofollow">Mis datos personales</a></li></ul></div> </section><?php }} ?>
