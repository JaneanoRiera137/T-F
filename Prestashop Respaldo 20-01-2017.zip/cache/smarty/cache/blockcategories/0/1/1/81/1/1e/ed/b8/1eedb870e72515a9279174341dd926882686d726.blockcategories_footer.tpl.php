<?php /*%%SmartyHeaderCode:19406584b86867a0ed8-04411981%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1eedb870e72515a9279174341dd926882686d726' => 
    array (
      0 => 'C:\\Bitnami\\prestashop-1.6.1.7-1\\apps\\prestashop\\htdocs\\themes\\default-bootstrap\\modules\\blockcategories\\blockcategories_footer.tpl',
      1 => 1473174314,
      2 => 'file',
    ),
    'c1258b763b56081cdd3a798b3a1b77d9c6269b50' => 
    array (
      0 => 'C:\\Bitnami\\prestashop-1.6.1.7-1\\apps\\prestashop\\htdocs\\themes\\default-bootstrap\\modules\\blockcategories\\category-tree-branch.tpl',
      1 => 1473174314,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '19406584b86867a0ed8-04411981',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_58819638a271e0_96799611',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_58819638a271e0_96799611')) {function content_58819638a271e0_96799611($_smarty_tpl) {?><section class="blockcategories_footer footer-block col-xs-12 col-sm-2"><h4>Categorías</h4><div class="category_footer toggle-footer"><div class="list"><ul class="tree dhtml"><li > <a href="http://192.168.87.2:81/prestashop/3-mujer" title="Aquí encontrará todas las colecciones de moda femenina. Esta categoría incluye todos los elementos básicos de su armario y mucho más: Zapatos, accesorios, camisetas impresas, vestidos femeninos, pantalones vaqueros de las mujeres!"> Mujer </a><ul><li > <a href="http://192.168.87.2:81/prestashop/4-tops" title="Choose from t-shirts, tops, blouses, short sleeves, long sleeves, tank tops, 3/4 sleeves and more. Find the cut that suits you the best!"> Tops </a><ul><li > <a href="http://192.168.87.2:81/prestashop/5-tshirts" title="The must have of your wardrobe, take a look at our different colors, shapes and style of our collection!"> T-shirts </a></li><li class="last"> <a href="http://192.168.87.2:81/prestashop/7-blouses" title="Match your favorites blouses with the right accessories for the perfect look."> Blouses </a></li></ul></li><li class="last"> <a href="http://192.168.87.2:81/prestashop/8-vestidos" title="Encuentre sus vestidos favoritos de nuestra amplia selección de vestidos de noche, ocasionales o de verano! Ofrecemos vestidos para cada día, cada estilo y cada ocasión."> Vestidos </a><ul><li > <a href="http://192.168.87.2:81/prestashop/9-casual-dresses" title="You are looking for a dress for every day? Take a look at our selection of dresses to find one that suits you."> Casual Dresses </a></li><li > <a href="http://192.168.87.2:81/prestashop/10-evening-dresses" title="Browse our different dresses to choose the perfect dress for an unforgettable evening!"> Evening Dresses </a></li><li class="last"> <a href="http://192.168.87.2:81/prestashop/11-summer-dresses" title="Short dress, long dress, silk dress, printed dress, you will find the perfect dress for summer."> Summer Dresses </a></li></ul></li></ul></li><li > <a href="http://192.168.87.2:81/prestashop/12-hombre" title=""> Hombre </a><ul><li > <a href="http://192.168.87.2:81/prestashop/13-sacos" title=""> Sacos </a></li><li > <a href="http://192.168.87.2:81/prestashop/14-zapatos" title=""> Zapatos </a><ul><li > <a href="http://192.168.87.2:81/prestashop/18-casual" title=""> Casual </a></li><li class="last"> <a href="http://192.168.87.2:81/prestashop/19-deportivo" title=""> Deportivo </a></li></ul></li><li > <a href="http://192.168.87.2:81/prestashop/15-camisas" title=""> Camisas </a></li><li > <a href="http://192.168.87.2:81/prestashop/16-camisetas" title=""> Camisetas </a></li><li class="last"> <a href="http://192.168.87.2:81/prestashop/17-pantalones" title=""> Pantalones </a></li></ul></li><li > <a href="http://192.168.87.2:81/prestashop/20-rebajas" title=""> Rebajas </a></li><li class="last"> <a href="http://192.168.87.2:81/prestashop/21-marcas" title=""> Marcas </a></li></ul></div></div> </section><?php }} ?>
