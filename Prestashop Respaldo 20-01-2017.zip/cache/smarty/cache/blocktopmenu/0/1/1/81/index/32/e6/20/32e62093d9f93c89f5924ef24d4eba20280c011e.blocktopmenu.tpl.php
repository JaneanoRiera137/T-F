<?php /*%%SmartyHeaderCode:24350584b86845fb3f5-87826588%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '32e62093d9f93c89f5924ef24d4eba20280c011e' => 
    array (
      0 => 'C:\\Bitnami\\prestashop-1.6.1.7-1\\apps\\prestashop\\htdocs\\themes\\default-bootstrap\\modules\\blocktopmenu\\blocktopmenu.tpl',
      1 => 1473174314,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '24350584b86845fb3f5-87826588',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_5882cd67122455_14496907',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5882cd67122455_14496907')) {function content_5882cd67122455_14496907($_smarty_tpl) {?><div id="block_top_menu" class="sf-contener clearfix col-lg-12"><div class="cat-title">Menú</div><ul class="sf-menu clearfix menu-content"><li><a href="http://192.168.87.2:81/prestashop/12-hombre" title="Hombre">Hombre</a><ul><li><a href="http://192.168.87.2:81/prestashop/13-sacos" title="Sacos">Sacos</a></li><li><a href="http://192.168.87.2:81/prestashop/14-zapatos" title="Zapatos">Zapatos</a><ul><li><a href="http://192.168.87.2:81/prestashop/18-casual" title="Casual">Casual</a></li><li><a href="http://192.168.87.2:81/prestashop/19-deportivo" title="Deportivo">Deportivo</a></li></ul></li><li><a href="http://192.168.87.2:81/prestashop/15-camisas" title="Camisas">Camisas</a></li><li><a href="http://192.168.87.2:81/prestashop/16-camisetas" title="Camisetas">Camisetas</a></li><li><a href="http://192.168.87.2:81/prestashop/17-pantalones" title="Pantalones">Pantalones</a></li></ul></li><li><a href="http://192.168.87.2:81/prestashop/3-mujer" title="Mujer">Mujer</a><ul><li><a href="http://192.168.87.2:81/prestashop/4-tops" title="Tops">Tops</a><ul><li><a href="http://192.168.87.2:81/prestashop/5-tshirts" title="T-shirts">T-shirts</a></li><li><a href="http://192.168.87.2:81/prestashop/7-blouses" title="Blouses">Blouses</a></li></ul></li><li><a href="http://192.168.87.2:81/prestashop/8-vestidos" title="Vestidos">Vestidos</a><ul><li><a href="http://192.168.87.2:81/prestashop/9-casual-dresses" title="Casual Dresses">Casual Dresses</a></li><li><a href="http://192.168.87.2:81/prestashop/10-evening-dresses" title="Evening Dresses">Evening Dresses</a></li><li><a href="http://192.168.87.2:81/prestashop/11-summer-dresses" title="Summer Dresses">Summer Dresses</a></li></ul></li><li class="category-thumbnail"><div><img src="http://192.168.87.2:81/prestashop/img/c/3-0_thumb.jpg" alt="Mujer" title="Mujer" class="imgm" /></div><div><img src="http://192.168.87.2:81/prestashop/img/c/3-1_thumb.jpg" alt="Mujer" title="Mujer" class="imgm" /></div></li></ul></li><li><a href="http://192.168.87.2:81/prestashop/20-rebajas" title="Rebajas">Rebajas</a></li><li><a href="http://192.168.87.2:81/prestashop/21-marcas" title="Marcas">Marcas</a></li></ul></div><?php }} ?>
