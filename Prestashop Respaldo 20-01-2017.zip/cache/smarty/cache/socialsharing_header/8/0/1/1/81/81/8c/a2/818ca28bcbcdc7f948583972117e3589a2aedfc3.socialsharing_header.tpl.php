<?php /*%%SmartyHeaderCode:17159588196524a5026-52104444%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '818ca28bcbcdc7f948583972117e3589a2aedfc3' => 
    array (
      0 => 'C:\\Bitnami\\prestashop-1.6.1.7-1\\apps\\prestashop\\htdocs\\modules\\socialsharing\\views\\templates\\hook\\socialsharing_header.tpl',
      1 => 1473174320,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '17159588196524a5026-52104444',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_5881975d938064_97149087',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5881975d938064_97149087')) {function content_5881975d938064_97149087($_smarty_tpl) {?><meta property="og:type" content="product" /><meta property="og:url" content="http://192.168.87.2:81/prestashop/home/8-casaca-yiconcept.html" /><meta property="og:title" content="Casaca &quot;YI&amp;CONCEPT&quot; - PrestaShop" /><meta property="og:site_name" content="PrestaShop" /><meta property="og:description" content="" /><meta property="og:image" content="http://192.168.87.2:81/prestashop/24-large_default/casaca-yiconcept.jpg" /><meta property="product:pretax_price:amount" content="57.14" /><meta property="product:pretax_price:currency" content="USD" /><meta property="product:price:amount" content="57.14" /><meta property="product:price:currency" content="USD" /><?php }} ?>
