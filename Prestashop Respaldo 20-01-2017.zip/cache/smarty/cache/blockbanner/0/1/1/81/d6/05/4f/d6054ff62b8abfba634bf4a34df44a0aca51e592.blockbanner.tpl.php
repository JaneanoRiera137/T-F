<?php /*%%SmartyHeaderCode:1702584b868795ebb6-04535498%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd6054ff62b8abfba634bf4a34df44a0aca51e592' => 
    array (
      0 => 'C:\\Bitnami\\prestashop-1.6.1.7-1\\apps\\prestashop\\htdocs\\modules\\blockbanner\\blockbanner.tpl',
      1 => 1473174316,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1702584b868795ebb6-04535498',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_5881963913a3d0_40223755',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5881963913a3d0_40223755')) {function content_5881963913a3d0_40223755($_smarty_tpl) {?><a href="http://192.168.87.2:81/prestashop/" title=""> <img class="img-responsive" src="http://192.168.87.2:81/prestashop/modules/blockbanner/img/sale70.png" alt="" title="" width="1170" height="65" /> </a><?php }} ?>
