<?php /*%%SmartyHeaderCode:21176584b86851413f8-33806758%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ddc2e385a436a13633f24a23d8e8c3a4ef0d21ef' => 
    array (
      0 => 'C:\\Bitnami\\prestashop-1.6.1.7-1\\apps\\prestashop\\htdocs\\modules\\homefeatured\\views\\templates\\hook\\tab.tpl',
      1 => 1473174318,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '21176584b86851413f8-33806758',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_5882cd6808b846_58781101',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5882cd6808b846_58781101')) {function content_5882cd6808b846_58781101($_smarty_tpl) {?><li><a data-toggle="tab" href="#homefeatured" class="homefeatured">Populares</a></li><?php }} ?>
