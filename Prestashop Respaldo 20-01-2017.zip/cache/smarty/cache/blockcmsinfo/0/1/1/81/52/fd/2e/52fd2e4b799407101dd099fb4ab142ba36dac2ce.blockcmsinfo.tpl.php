<?php /*%%SmartyHeaderCode:20266584b8684c037f0-22461497%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '52fd2e4b799407101dd099fb4ab142ba36dac2ce' => 
    array (
      0 => 'C:\\Bitnami\\prestashop-1.6.1.7-1\\apps\\prestashop\\htdocs\\modules\\blockcmsinfo\\blockcmsinfo.tpl',
      1 => 1473174316,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '20266584b8684c037f0-22461497',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_58819634b0b430_07934713',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_58819634b0b430_07934713')) {function content_58819634b0b430_07934713($_smarty_tpl) {?><div id="cmsinfo_block"><div class="col-xs-6"><ul><li><em class="icon-truck" id="icon-truck"></em><div class="type-text"><h3>Lorem Ipsum</h3><p>Lorem ipsum dolor sit amet conse ctetur voluptate velit esse cillum dolore eu</p></div></li><li><em class="icon-phone" id="icon-phone"></em><div class="type-text"><h3>Dolor Sit Amet</h3><p>Lorem ipsum dolor sit amet conse ctetur voluptate velit esse cillum dolore eu</p></div></li><li><em class="icon-credit-card" id="icon-credit-card"></em><div class="type-text"><h3>Ctetur Voluptate</h3><p>Lorem ipsum dolor sit amet conse ctetur voluptate velit esse cillum dolore eu</p></div></li></ul></div><div class="col-xs-6"><h3>Custom Block</h3><p><strong class="dark">Lorem ipsum dolor sit amet conse ctetu</strong></p><p>Sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit.</p></div></div><?php }} ?>
