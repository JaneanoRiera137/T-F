<?php /*%%SmartyHeaderCode:13302584b86854446c3-23368787%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4cba543fbe4aa1720a47e2cbcc8a2908c3ec893c' => 
    array (
      0 => 'C:\\Bitnami\\prestashop-1.6.1.7-1\\apps\\prestashop\\htdocs\\modules\\blockspecials\\views\\templates\\hook\\tab.tpl',
      1 => 1473174318,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '13302584b86854446c3-23368787',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_588197d8e9abb0_82417251',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_588197d8e9abb0_82417251')) {function content_588197d8e9abb0_82417251($_smarty_tpl) {?><li><a data-toggle="tab" href="#blockspecials" class="blockspecials">Promociones especiales</a></li><?php }} ?>
