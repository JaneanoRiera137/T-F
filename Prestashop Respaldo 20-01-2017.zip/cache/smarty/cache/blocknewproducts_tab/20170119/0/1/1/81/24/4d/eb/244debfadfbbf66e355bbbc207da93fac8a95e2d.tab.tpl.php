<?php /*%%SmartyHeaderCode:12571584b8684ea1bd3-42407689%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '244debfadfbbf66e355bbbc207da93fac8a95e2d' => 
    array (
      0 => 'C:\\Bitnami\\prestashop-1.6.1.7-1\\apps\\prestashop\\htdocs\\modules\\blocknewproducts\\views\\templates\\hook\\tab.tpl',
      1 => 1473174318,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '12571584b8684ea1bd3-42407689',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_588197d4299311_09021219',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_588197d4299311_09021219')) {function content_588197d4299311_09021219($_smarty_tpl) {?><li><a data-toggle="tab" href="#blocknewproducts" class="blocknewproducts">Nuevos</a></li><?php }} ?>
