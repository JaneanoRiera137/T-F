<?php /*%%SmartyHeaderCode:19037588196534f0ec2-28676896%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'bd3cff7d37eb3faeddb145713afe2e6435ed4e81' => 
    array (
      0 => 'C:\\Bitnami\\prestashop-1.6.1.7-1\\apps\\prestashop\\htdocs\\modules\\productpaymentlogos\\views\\templates\\hook\\productpaymentlogos.tpl',
      1 => 1473174318,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '19037588196534f0ec2-28676896',
  'variables' => 
  array (
    'banner_title' => 0,
    'banner_link' => 0,
    'module_dir' => 0,
    'banner_img' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_588196535617d7_47123835',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_588196535617d7_47123835')) {function content_588196535617d7_47123835($_smarty_tpl) {?><div id="product_payment_logos"><div class="box-security"><h5 class="product-heading-h5"></h5> <img src="/prestashop/modules/productpaymentlogos/img/payment-logo.png" alt="" class="img-responsive" /></div></div><?php }} ?>
