<?php /*%%SmartyHeaderCode:28693584b86849fb2b6-62214607%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0605aa601fe17c3162984e16b892b51f95a67718' => 
    array (
      0 => 'C:\\Bitnami\\prestashop-1.6.1.7-1\\apps\\prestashop\\htdocs\\modules\\blockfacebook\\blockfacebook.tpl',
      1 => 1473174316,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '28693584b86849fb2b6-62214607',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_5881963436d798_41801540',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5881963436d798_41801540')) {function content_5881963436d798_41801540($_smarty_tpl) {?><div id="fb-root"></div><div id="facebook_block" class="col-xs-4"><h4 >Síguenos en Facebook</h4><div class="facebook-fanbox"><div class="fb-like-box" data-href="https://www.facebook.com/totalfashionh/" data-colorscheme="light" data-show-faces="true" data-header="false" data-stream="false" data-show-border="false"></div></div></div><?php }} ?>
