<?php /*%%SmartyHeaderCode:26418584b8687da6f84-06357338%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '441d2b3e2357ff025c9ad982b16b8a8fd39180df' => 
    array (
      0 => 'C:\\Bitnami\\prestashop-1.6.1.7-1\\apps\\prestashop\\htdocs\\themes\\default-bootstrap\\modules\\homeslider\\homeslider.tpl',
      1 => 1473174314,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '26418584b8687da6f84-06357338',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_588196393a3ed9_98705205',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_588196393a3ed9_98705205')) {function content_588196393a3ed9_98705205($_smarty_tpl) {?><div id="homepage-slider"><ul id="homeslider" style="max-height:448px;"><li class="homeslider-container"> <a href="http://www.prestashop.com/?utm_source=back-office&amp;utm_medium=v16_homeslider&amp;utm_campaign=back-office-EN&amp;utm_content=download" title="sample-1"> <img src="http://192.168.87.2:81/prestashop/modules/homeslider/images/8c1e3552f25ec8d37f21c7a4adb535fe60e96a1f_Slider 1 TF final.png" width="779" height="448" alt="sample-1" /> </a></li><li class="homeslider-container"> <a href="http://www.prestashop.com/?utm_source=back-office&amp;utm_medium=v16_homeslider&amp;utm_campaign=back-office-EN&amp;utm_content=download" title="sample-2"> <img src="http://192.168.87.2:81/prestashop/modules/homeslider/images/2fe9fcbfd6cee296ea54979590b82606ec746ed9_Slider 2.1 TF.png" width="779" height="448" alt="sample-2" /> </a></li><li class="homeslider-container"> <a href="http://www.prestashop.com/?utm_source=back-office&amp;utm_medium=v16_homeslider&amp;utm_campaign=back-office-EN&amp;utm_content=download" title="sample-3"> <img src="http://192.168.87.2:81/prestashop/modules/homeslider/images/e28c5c9c436f56aab518c7db10a277de2af0c5e5_Slider 3 TF.png" width="779" height="448" alt="sample-3" /> </a></li></ul></div><?php }} ?>
