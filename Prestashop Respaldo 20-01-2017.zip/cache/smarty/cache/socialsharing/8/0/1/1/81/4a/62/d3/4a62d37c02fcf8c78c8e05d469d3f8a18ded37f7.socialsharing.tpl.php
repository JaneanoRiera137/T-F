<?php /*%%SmartyHeaderCode:236045881965328fc90-85327622%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4a62d37c02fcf8c78c8e05d469d3f8a18ded37f7' => 
    array (
      0 => 'C:\\Bitnami\\prestashop-1.6.1.7-1\\apps\\prestashop\\htdocs\\modules\\socialsharing\\views\\templates\\hook\\socialsharing.tpl',
      1 => 1473174320,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '236045881965328fc90-85327622',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_5881975edc4e39_24793878',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5881975edc4e39_24793878')) {function content_5881975edc4e39_24793878($_smarty_tpl) {?><p class="socialsharing_product list-inline no-print"> <button data-type="twitter" type="button" class="btn btn-default btn-twitter social-sharing"> <i class="icon-twitter"></i> Tweet </button> <button data-type="facebook" type="button" class="btn btn-default btn-facebook social-sharing"> <i class="icon-facebook"></i> Compartir </button> <button data-type="google-plus" type="button" class="btn btn-default btn-google-plus social-sharing"> <i class="icon-google-plus"></i> Google+ </button> <button data-type="pinterest" type="button" class="btn btn-default btn-pinterest social-sharing"> <i class="icon-pinterest"></i> Pinterest </button></p><?php }} ?>
