<?php /*%%SmartyHeaderCode:17399584b86855c87f6-42441198%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c9351f4fe5ea0d70f6209b7c4bdb5bbebed18640' => 
    array (
      0 => 'C:\\Bitnami\\prestashop-1.6.1.7-1\\apps\\prestashop\\htdocs\\modules\\blocknewproducts\\views\\templates\\hook\\blocknewproducts_home.tpl',
      1 => 1473174318,
      2 => 'file',
    ),
    '000e089f57fd50cc8fe2f0b6eb6a0950d01d99dc' => 
    array (
      0 => 'C:\\Bitnami\\prestashop-1.6.1.7-1\\apps\\prestashop\\htdocs\\themes\\default-bootstrap\\product-list.tpl',
      1 => 1473174314,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '17399584b86855c87f6-42441198',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_588197d9d364a7_79524176',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_588197d9d364a7_79524176')) {function content_588197d9d364a7_79524176($_smarty_tpl) {?><ul id="blocknewproducts" class="product_list grid row blocknewproducts tab-pane"><li class="ajax_block_product col-xs-12 col-sm-4 col-md-3 first-in-line last-line first-item-of-tablet-line first-item-of-mobile-line last-mobile-line"><div class="product-container" itemscope itemtype="https://schema.org/Product"><div class="left-block"><div class="product-image-container"> <a class="product_img_link" href="http://192.168.87.2:81/prestashop/home/8-casaca-yiconcept.html" title="Casaca &quot;YI&amp;CONCEPT&quot;" itemprop="url"> <img class="replace-2x img-responsive" src="http://192.168.87.2:81/prestashop/24-home_default/casaca-yiconcept.jpg" alt="Casaca &quot;YI&amp;CONCEPT&quot;" title="Casaca &quot;YI&amp;CONCEPT&quot;" width="250" height="250" itemprop="image" /> </a><div class="quick-view-wrapper-mobile"> <a class="quick-view-mobile" href="http://192.168.87.2:81/prestashop/home/8-casaca-yiconcept.html" rel="http://192.168.87.2:81/prestashop/home/8-casaca-yiconcept.html"> <i class="icon-eye-open"></i> </a></div> <a class="quick-view" href="http://192.168.87.2:81/prestashop/home/8-casaca-yiconcept.html" rel="http://192.168.87.2:81/prestashop/home/8-casaca-yiconcept.html"> <span>Vista r&aacute;pida</span> </a><div class="content_price" itemprop="offers" itemscope itemtype="https://schema.org/Offer"> <span itemprop="price" class="price product-price"> $57.14 </span><meta itemprop="priceCurrency" content="USD" /> <span class="unvisible"><link itemprop="availability" href="https://schema.org/InStock" />En stock </span></div> <a class="new-box" href="http://192.168.87.2:81/prestashop/home/8-casaca-yiconcept.html"> <span class="new-label">Nuevo</span> </a></div></div><div class="right-block"><h5 itemprop="name"> <a class="product-name" href="http://192.168.87.2:81/prestashop/home/8-casaca-yiconcept.html" title="Casaca &quot;YI&amp;CONCEPT&quot;" itemprop="url" > Casaca &quot;YI&amp;CONCEPT&quot; </a></h5><p class="product-desc" itemprop="description"></p><div class="content_price"> <span class="price product-price"> $57.14 </span></div><div class="button-container"> <a class="button ajax_add_to_cart_button btn btn-default" href="https://192.168.87.2:446/prestashop/cart?add=1&amp;id_product=8&amp;token=e91635456e29a39ab0d6a3dafda972be" rel="nofollow" title="A&ntilde;adir al carrito" data-id-product-attribute="0" data-id-product="8" data-minimal_quantity="1"> <span>A&ntilde;adir al carrito</span> </a> <a class="button lnk_view btn btn-default" href="http://192.168.87.2:81/prestashop/home/8-casaca-yiconcept.html" title="Ver"> <span>M&aacute;s</span> </a></div><div class="product-flags"></div> <span class="availability"> <span class=" label-success"> En stock </span> </span></div></div></li></ul><?php }} ?>
