<?php /*%%SmartyHeaderCode:30865584b86852c7a17-34038502%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ee92a0f22d674db927548fa20a56a99aaac21e84' => 
    array (
      0 => 'C:\\Bitnami\\prestashop-1.6.1.7-1\\apps\\prestashop\\htdocs\\modules\\blockbestsellers\\views\\templates\\hook\\tab.tpl',
      1 => 1473174316,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '30865584b86852c7a17-34038502',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_5882cd68435f35_49567607',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5882cd68435f35_49567607')) {function content_5882cd68435f35_49567607($_smarty_tpl) {?><li><a data-toggle="tab" href="#blockbestsellers" class="blockbestsellers">Los más vendidos</a></li><?php }} ?>
