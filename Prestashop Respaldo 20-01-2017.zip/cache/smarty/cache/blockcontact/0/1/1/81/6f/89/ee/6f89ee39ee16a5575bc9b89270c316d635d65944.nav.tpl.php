<?php /*%%SmartyHeaderCode:17213584b8687c2d3b3-52910880%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6f89ee39ee16a5575bc9b89270c316d635d65944' => 
    array (
      0 => 'C:\\Bitnami\\prestashop-1.6.1.7-1\\apps\\prestashop\\htdocs\\themes\\default-bootstrap\\modules\\blockcontact\\nav.tpl',
      1 => 1473174314,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '17213584b8687c2d3b3-52910880',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_5881963926f2e6_69873247',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5881963926f2e6_69873247')) {function content_5881963926f2e6_69873247($_smarty_tpl) {?><div id="contact-link" > <a href="https://192.168.87.2:446/prestashop/contact-us" title="Contacte con nosotros">Contacte con nosotros</a></div> <span class="shop-phone"> <i class="icon-phone"></i>Llámenos ahora: <strong>0123-456-789</strong> </span><?php }} ?>
